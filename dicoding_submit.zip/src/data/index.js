export const test = [
  {
    title: "Membahas 10 Framework JavaScript Terbaik untuk Pengembangan Web",
  },
  { title: "Tips & Trik untuk Meningkatkan Kinerja Aplikasi React Anda" },
  {
    title: "Mengapa Redux Masih Penting dalam Pengembangan Aplikasi Modern?",
  },
  {
    title:
      "Panduan Lengkap Menggunakan Next.js untuk Membangun Aplikasi Web yang Tangguh",
  },
];
