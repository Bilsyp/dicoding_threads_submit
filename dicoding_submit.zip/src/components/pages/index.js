export { default as HomePage } from "./HomePage";
export { default as LoginPage } from "./LoginPage";
export { default as SignUpPage } from "./SignUpPage";
export { default as ProfilePage } from "./ProfilePage";
export { default as NotFoundPage } from "./NotFoundPage";
export { default as LeaderBoardPage } from "./LeaderBoardPage";
